#!/usr/bin/env python
import os
os.chdir("/home/skakeel/vrep")
os.system("./vrep.sh $(find ~/catkin_ws -iname my_octabot.ttt)")
