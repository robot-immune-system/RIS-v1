// ROS node to mobilize Reactive Immune Cells of Innate Immunity against fault to perform recovery actions
// Authors: Maria Akram, GAli Raza. (maria.akram@uet.edu.pk, ali.raza@ymail.com)
// =======================================================================================================
#include <ros/ros.h>
#include <geometry_msgs/Pose.h>
#include <geometry_msgs/Twist.h>
#include <std_msgs/Int32.h>

    ros::Publisher pub;
    	float cell_left_x = 0;
	float cell_left_z = 6;
	float cell_right_x = 0;
	float cell_right_z = -6;
	float cell_front_x = 6;
	float cell_front_z = 0;
	float cell_back_x = -6;
	float cell_back_z =0;
	float a = 50;
	float b = 50;
	float c = 40;
	float d = 35;
	float sum=0;

void callbackBump(const geometry_msgs::PoseConstPtr &value)
{
	geometry_msgs::Twist vel;
	float b_hit=value->position.x;
	float bl_hit=value->position.y;
	float br_hit=value->position.z;
	float l_hit=value->orientation.x;
	float r_hit=value->orientation.y;
	float fl_hit=value->orientation.z;
	float fr_hit=value->orientation.w;
   if (b_hit==1||bl_hit==1||br_hit==1)
	{
		if(c>0)
		{c=c-10;}
		sum=a+b+c+d;
	vel.linear.x = (((a*cell_left_x)+(b*cell_right_x)+(c*cell_back_x)+(d*cell_front_x))/sum);
	vel.angular.z = (((a*cell_left_z)+(b*cell_right_z)+(c*cell_back_z)+(d*cell_front_z))/sum);
	pub.publish(vel);
	ROS_INFO_STREAM("hit from back:trying to be stable"<<a<<b<<c<<d);
}
	else if(fr_hit==1||fl_hit==1)
{
		if(d>0)
{d=d-10;}
	sum=a+b+c+d;
	vel.linear.x = (((a*cell_left_x)+(b*cell_right_x)+(c*cell_back_x)+(d*cell_front_x))/sum);
	vel.angular.z = (((a*cell_left_z)+(b*cell_right_z)+(c*cell_back_z)+(d*cell_front_z))/sum);
	pub.publish(vel);
	ROS_INFO_STREAM("hit from front:trying to be stable"<<a<<b<<c<<d);
	ros::spinOnce();
}
	else if (l_hit == 1)
	{
		if(a>0)
	{a=a-10;}
	sum=a+b+c+d;
	vel.linear.x = (((a*cell_left_x)+(b*cell_right_x)+(c*cell_back_x)+(d*cell_front_x))/sum);
	vel.angular.z = (((a*cell_left_z)+(b*cell_right_z)+(c*cell_back_z)+(d*cell_front_z))/sum);
	pub.publish(vel);
	ROS_INFO_STREAM("hit from left:trying to be stable"<<a<<b<<c<<d);
	ros::spinOnce();
}
else if (r_hit == 1)
	{
		if(b>0)
{b=b-10;}
	sum=a+b+c+d;
	vel.linear.x = (((a*cell_left_x)+(b*cell_right_x)+(c*cell_back_x)+(d*cell_front_x))/sum);
	vel.angular.z = (((a*cell_left_z)+(b*cell_right_z)+(c*cell_back_z)+(d*cell_front_z))/sum);
	pub.publish(vel);
	ROS_INFO_STREAM("hit from right:trying to be stable"<<a<<b<<c<<d);
	ros::spinOnce();}
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "Reactive_cell");
    ros::NodeHandle nh;
    pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 100);
    ros::Subscriber sub = nh.subscribe("/Hit", 10, callbackBump);
    ros::spin();
    return 0;
}
