// ROS node to stimulate proliferation of fault specific T-Cells of Adaptive Immunity to perform recovery actions
// Authors: Maria Akram, GAli Raza. (maria.akram@uet.edu.pk, ali.raza@ymail.com)
// ==============================================================================================================
#include <ros/ros.h>
#include <geometry_msgs/Vector3.h>
#include <geometry_msgs/Quaternion.h>
#include <geometry_msgs/Twist.h>
#include <std_msgs/Int32.h>
#include <geometry_msgs/Pose.h>
#include <sensor_msgs/JointState.h>
geometry_msgs::Quaternion pop;
geometry_msgs::Twist vel;
    ros::Publisher pub;
	ros::Publisher pub1;
    void callbackTorque(const geometry_msgs::Vector3 inf);
    float previous_value=0; float current_value=0;
	float value=0;
	float count=0;
	float check=0;
	float b_hit=0;
	float bl_hit=0;
	float br_hit=0;
	float l_hit=0;
	float r_hit=0;
	float fl_hit=0;
	float fr_hit=0;
	float cell_left_x = 0;
	float cell_left_z = 3;
	float cell_right_x = 0;
	float cell_right_z = -3;
	float cell_front_x = 3;
	float cell_front_z = 0;
	float cell_back_x = -3;
	float cell_back_z =0;
	float a = 1;
	float b = 1;
	float c = 1;
	float d = 1;
	float sum=0;
	float cells=0;
	float gripper_force=0;

void callbackgripper(const sensor_msgs::JointStateConstPtr &joint)
{

    gripper_force = joint->effort[4];
    if (gripper_force<-1)
{
	vel.linear.x = -(double)rand()/((double)RAND_MAX+1); //to generate a random number between 0-1 & -ve sign to reverse motion
	vel.angular.z = -(double)rand()/((double)RAND_MAX+1);
	pub.publish(vel);
	ROS_INFO_STREAM("gripper hits:trying to be stable");
	ros::spinOnce();
}
}

void callbackDendritiCells(const geometry_msgs::Vector3ConstPtr &dc)
{
cells=dc->x;
}
void callbackReactiveCell(const geometry_msgs::PoseConstPtr &inf)
{
	geometry_msgs::Quaternion pop;
	geometry_msgs::Twist vel;
	current_value=inf->position.x;
        if (cells>0)
{
 if (current_value > 0.05 && previous_value > 0.05)
	{count++;
	check=0+count;
	ROS_INFO("Count:%f", check);

	if(check>5)
{
        ROS_INFO("T Cells in action");
	 if (b_hit==1||bl_hit==1||br_hit==1)
	{
		d=d+2;
	ROS_INFO("d:%f", d);
	pop.x=a;
	pop.y=b;
	pop.z=c;
	pop.w=d;
	pub1.publish(pop);
	ROS_INFO_STREAM("publishing population");
	ros::spinOnce();

	sum=a+b+c+d;
	vel.linear.x = (((a*cell_left_x)+(b*cell_right_x)+(c*cell_back_x)+(d*cell_front_x))/sum);
	vel.angular.z = (((a*cell_left_z)+(b*cell_right_z)+(c*cell_back_z)+(d*cell_front_z))/sum);
	pub.publish(vel);
	ROS_INFO_STREAM("hit from back:trying to be stable"<<a<<b<<c<<d);
	ros::spinOnce();

}
	else if(fr_hit==1||fl_hit==1)
{
		c=c+2;
	pop.x=a;
	pop.y=b;
	pop.z=c;
	pop.w=d;
	pub1.publish(pop);
	ROS_INFO_STREAM("publishing population");
	ros::spinOnce();

	sum=a+b+c+d;
	vel.linear.x = (((a*cell_left_x)+(b*cell_right_x)+(c*cell_back_x)+(d*cell_front_x))/sum);
	vel.angular.z = (((a*cell_left_z)+(b*cell_right_z)+(c*cell_back_z)+(d*cell_front_z))/sum);
	pub.publish(vel);
	ROS_INFO_STREAM("hit from front:trying to be stable"<<a<<b<<c<<d);
	ros::spinOnce();
}
	else if (l_hit == 1)
	{
		b=b+2;
	pop.x=a;
	pop.y=b;
	pop.z=c;
	pop.w=d;
	pub1.publish(pop);
	ROS_INFO_STREAM("publishing population");
	ros::spinOnce();

	sum=a+b+c+d;
	vel.linear.x = (((a*cell_left_x)+(b*cell_right_x)+(c*cell_back_x)+(d*cell_front_x))/sum);
	vel.angular.z = (((a*cell_left_z)+(b*cell_right_z)+(c*cell_back_z)+(d*cell_front_z))/sum);
	pub.publish(vel);
	ROS_INFO_STREAM("hit from left:trying to be stable"<<a<<b<<c<<d);
	ros::spinOnce();
}
else if (r_hit == 1)
	{
		a=a+2;
	pop.x=a;
	pop.y=b;
	pop.z=c;
	pop.w=d;
	pub1.publish(pop);
	ROS_INFO_STREAM("publishing population");
	ros::spinOnce();

	sum=a+b+c+d;
	vel.linear.x = (((a*cell_left_x)+(b*cell_right_x)+(c*cell_back_x)+(d*cell_front_x))/sum);
	vel.angular.z = (((a*cell_left_z)+(b*cell_right_z)+(c*cell_back_z)+(d*cell_front_z))/sum);
	pub.publish(vel);
	ROS_INFO_STREAM("hit from right:trying to be stable"<<a<<b<<c<<d);
	ros::spinOnce();}
 if (gripper_force>1)
{
	vel.linear.x = -1;
	vel.angular.z = 0;
	pub.publish(vel);
	ROS_INFO_STREAM("gripper hits:trying to be stable");
	ros::spinOnce();
}

}
}}
	if (current_value<0.05 && previous_value<0.05)
{
	count=0;
if(a>2)
{a=a-1;}
if(b>2)
{b=b-1;}
if(c>2)
{c=c-1;}
if(d>2)
{d=d-1;}


	pop.x=a;
	pop.y=b;
	pop.z=c;
	pop.w=d;
	pub1.publish(pop);
	ROS_INFO_STREAM("publishing population");
	ros::spinOnce();
}
        ROS_INFO("previous_slope:%f  current_slope:%f", previous_value, current_value);
         value=current_value;
	previous_value=value;
	pop.x=a;
	pop.y=b;
	pop.z=c;
	pop.w=d;
	pub1.publish(pop);
	ROS_INFO_STREAM("publishing population");
	ros::spinOnce();

}
void callbackBump(const geometry_msgs::PoseConstPtr &value)
{
	geometry_msgs::Twist vel;
	 b_hit=value->position.x;
	 bl_hit=value->position.y;
	 br_hit=value->position.z;
	 l_hit=value->orientation.x;
	 r_hit=value->orientation.y;
	 fl_hit=value->orientation.z;
	 fr_hit=value->orientation.w;
  }
int main(int argc, char **argv)
{
    ros::init(argc, argv, "T_cell");
    ros::NodeHandle nh;

	pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 100);
	pub1 = nh.advertise<geometry_msgs::Quaternion>("/cellPopulation", 10);
    ros::Subscriber sub = nh.subscribe("/Inflammation", 10, callbackReactiveCell);
    ros::Subscriber sub_ = nh.subscribe("/Hit", 10, callbackBump);
	ros::Subscriber sub_1 = nh.subscribe("/DCs", 10, callbackDendritiCells);
	ros::Subscriber sub2 = nh.subscribe("/joint_state", 10, callbackgripper);
    ros::spin();
    return 0;
}

