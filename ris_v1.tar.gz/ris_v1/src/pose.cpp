// ROS node to check the accuracy of task completion in terms of linear and angular distance
// Authors: Maria Akram, GAli Raza. (maria.akram@uet.edu.pk, ali.raza@ymail.com)
// =========================================================================================
#include <ros/ros.h>
#include <move_base_msgs/MoveBaseActionFeedback.h>
#include <move_base_msgs/MoveBaseActionResult.h>
#include <move_base_msgs/MoveBaseActionGoal.h>
#include <cmath>
#include <geometry_msgs/Vector3.h>
	ros::Publisher pub;
	float pos_x=0;
	float pos_y=0;
	float pos_z=0;
	float theta_1=0;
	float theta_2=0;
	float theta_3=0;
	float theta_4=0;
	float res=0;
	float goal_x=0;
	float goal_y=0;
	float goal_z=0;
	float theta_x=0;
	float theta_y=0;
	float theta_z=0;
	float theta_w=0;

void callbackResult(const  move_base_msgs::MoveBaseActionResult rslt);
void callbackfeed(const  move_base_msgs::MoveBaseActionFeedback fdbk);
void callbackGoal(const  move_base_msgs::MoveBaseActionGoal gol);

void callbackGoal(const  move_base_msgs::MoveBaseActionGoalConstPtr &gol)
{
	 goal_x=gol->goal.target_pose.pose.position.x;
	 goal_y=gol->goal.target_pose.pose.position.y;
	 goal_z=gol->goal.target_pose.pose.position.z;
	 theta_x=gol->goal.target_pose.pose.orientation.x;
	 theta_y=gol->goal.target_pose.pose.orientation.y;
	 theta_z=gol->goal.target_pose.pose.orientation.z;
	 theta_w=gol->goal.target_pose.pose.orientation.w;
	 ROS_INFO_STREAM("Goal:"<<gol->goal.target_pose.pose);
}

void callbackResult(const  move_base_msgs::MoveBaseActionResultConstPtr &rslt)
{
	geometry_msgs::Vector3 msg;
	float res=rslt->status.status;
	ROS_INFO_STREAM("Result:"<<res);
if(res==2)
{
	ROS_INFO_STREAM("Recieved:"<<pos_x<<pos_y<<pos_z<<theta_1<<theta_2<<theta_3<<theta_4);
	ROS_INFO("CANCEL_GOAL");
}
else if (res==3)
{
	float euclidean_dist = sqrt(((goal_x-pos_x)*(goal_x-pos_x))+((goal_y-pos_y)*(goal_y-pos_y)));
	ROS_INFO_STREAM("Dist:"<<euclidean_dist);
msg.x=euclidean_dist;
msg.y=pos_x;
msg.z=pos_y;
pub.publish(msg);
ros::spinOnce();
}
}

void callbackfeed( const  move_base_msgs::MoveBaseActionFeedbackConstPtr &fdbk)
{
	 pos_x=fdbk->feedback.base_position.pose.position.x;
	 pos_y=fdbk->feedback.base_position.pose.position.y;
	 pos_z=fdbk->feedback.base_position.pose.position.z;
	 theta_1=fdbk->feedback.base_position.pose.orientation.x;
	 theta_2=fdbk->feedback.base_position.pose.orientation.y;
	 theta_3=fdbk->feedback.base_position.pose.orientation.z;
	 theta_4=fdbk->feedback.base_position.pose.orientation.w;
	 ROS_INFO_STREAM("Recieved_direct:"<<fdbk->feedback.base_position.pose.position);
	 ROS_INFO_STREAM("Recieved_direct:"<<fdbk->feedback.base_position.pose.orientation);
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "feedback");
	ros::NodeHandle nh;
	pub = nh.advertise<geometry_msgs::Vector3>("/Distance",10);
	ros::Subscriber sub = nh.subscribe("/move_base/feedback", 10, callbackfeed);
	ros::Subscriber sub1 = nh.subscribe("/move_base/result", 10, callbackResult);
	ros::Subscriber sub2 = nh.subscribe("/move_base/goal", 10, callbackGoal);
	ros::spin();
	return 0;
}
