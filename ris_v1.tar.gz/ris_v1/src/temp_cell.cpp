// ROS node to mobilize Reactive Immune Cells of Innate Immunity against fault to perform recovery actions
// Authors: Maria Akram, GAli Raza. (maria.akram@uet.edu.pk, ali.raza@ymail.com)
// =======================================================================================================
#include <ros/ros.h>
#include <geometry_msgs/Vector3.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/Pose.h>
int count=0;
    ros::Publisher pub;

float tmp;
void callbackInfo_temp(const geometry_msgs::PoseConstPtr &inf)
{
tmp=inf->position.z; //temp function value

}
void callbackTempCell2(const geometry_msgs::Vector3Ptr &value)
{
	 geometry_msgs::Twist mov;

	float reading1=value->x;
	float reading2=value->y;

 for(int i=0;i<6;i++)
{
if(tmp>0.5)
{
if (reading1>75 || reading2>75)
   {
 	mov.linear.x = 0;
	mov.angular.z = 0;
	pub.publish(mov);
	ros::spinOnce();
}}
}
}
int main(int argc, char **argv)
{
    ros::init(argc, argv, "temp_reactive_cell_2");
    ros::NodeHandle nh;
    pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 10);
    ros::Subscriber sub = nh.subscribe("/Temperature", 100, callbackTempCell2);
	ros::Subscriber sub1 = nh.subscribe("/Inflammation", 10, callbackInfo_temp);
    ros::spin();
    return 0;
}


