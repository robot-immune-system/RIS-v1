// ROS node to mature dendtritic cells for the stimulation of T-cells of adaptive immunity
// Authors: Maria Akram, GAli Raza. (maria.akram@uet.edu.pk, ali.raza@ymail.com)
// =======================================================================================
#include <ros/ros.h>
#include <geometry_msgs/Vector3.h>
#include <geometry_msgs/Twist.h>
#include <std_msgs/Int32.h>
#include <geometry_msgs/Pose.h>


    ros::Publisher pub;
    float previous_inf=0; float current_inf=0;
	float count=0;
	float check=0;
float MDC=0;
void callbackDendriticCell(const geometry_msgs::PoseConstPtr &value)
{
    	geometry_msgs::Vector3 dc;
	current_inf=value->position.x;
         if (current_inf > 0.1 && previous_inf > 0.1)
	{count++;
	check=0+count;
	ROS_INFO("Count:%f", check);
	ROS_INFO("DCs are maturing");
	if(check>=20)
{	ROS_INFO("DCs are ready to activate T Cells");
        MDC =MDC +1;
	ROS_INFO("DC:%f", MDC);
	dc.x = MDC;
	dc.y=count;
	pub.publish(dc);
	ROS_INFO("handover to adaptive immune system");
	ros::spinOnce();
}
}
	if (current_inf<0.051 && previous_inf<0.051)
{
	count=0;
	MDC=0;

}
	previous_inf=current_inf;
	dc.x = MDC;
	dc.y=count;
	pub.publish(dc);
	ros::spinOnce();
}


int main(int argc, char **argv)
{
    ros::init(argc, argv, "DendritiCells");
    ros::NodeHandle nh;
    pub = nh.advertise<geometry_msgs::Vector3>("/DCs", 100);
    ros::Subscriber sub = nh.subscribe("/Inflammation", 10, callbackDendriticCell);
    ros::spin();
    return 0;
}

